function fixRobloxUI() {
    // fix sidebar
    const sidebar = document.querySelector('.left-nav');
    if (sidebar) {
        sidebar.style.display = "block";
    }

    // fix menu button
    const button = document.querySelector('#header-menu-icon, button.menu-button');
    if (button) {
        button.style.display = "inline-flex";
        button.style.visibility = "visible";
        button.style.opacity = "1";
    }
}

// run once
fixRobloxUI();

// roblox UI reload fix
const observer = new MutationObserver(() => {
    fixRobloxUI();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});